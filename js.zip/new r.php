<?php
session_start();
include('connect.php');
date_default_timezone_set("Asia/Colombo");

?>


<html>
<?php 
include("head.php");
include("connect.php");
?>
<body class="hold-transition skin-blue sidebar-mini">

	
	<br><br><br><br>
	
	
	<br><br><br><br><br>
	<center>
<h1><small class="label  bg-red">Error</small></h1>	
<h3><small class="label  bg-red">Amount is insufficient</small></h3>
	</center>
	
	
	
	<?php
	$dds=$_GET['id'];
	$result = $db->prepare("SELECT * FROM credit_sales_order WHERE order_id='$dds' ORDER by order_id DESC");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
				
				
				
			?>
                
				<?php  $g=$row['amount_left'];
				$g1=$row['amount'];
				$gr5=$g1-$g;
				echo $gr5;
				}?>
	
	<?php
	$result = $db->prepare("SELECT SUM(amount) FROM sales WHERE order_id='$dds' ORDER by order_id DESC");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
				
				
				
			?><br>
                
				<?php $dddr= $row['SUM(amount)'];}?>
							 
							 
							 
							 <?php
	$result = $db->prepare("SELECT SUM(interest) FROM sales WHERE order_id='$dds' ");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
				
				
				
			?>
                
				<?php $ddr =$row['SUM(interest)'];
				          $dr= $dddr-$ddr;
						  echo $dr;
						  }?><br>
	
	 <?php echo $gr5-$dr;?><br>
	<?php echo$g1-$dr;
	 ?>
	
	
	
	
	
	
	 <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="../../plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="../../plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="../../plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

</body>
</html>