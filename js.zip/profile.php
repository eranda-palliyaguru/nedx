<!DOCTYPE html>
<html>
<?php 
include("head.php");
include("connect.php");
?>
<body class="hold-transition skin-blue sidebar-mini">
<?php 
include_once("auth.php");
$r=$_SESSION['SESS_LAST_NAME'];

if($r =='Cashier'){

header("location:./../../../index.php");
}
if($r =='admin'){

include_once("sidebar.php");
}
?>




<link rel="stylesheet" href="datepicker.css"
        type="text/css" media="all" />
    <script src="datepicker.js" type="text/javascript"></script>
    <script src="datepicker.ui.min.js"
        type="text/javascript"></script>
 <script type="text/javascript">
     
		 $(function(){
        $("#datepicker1").datepicker({ dateFormat: 'yy/mm/dd' });
        $("#datepicker2").datepicker({ dateFormat: 'yy/mm/dd' });
       
    });

    </script>




    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Profile 
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
       
        <li class="active">Profile</li>
      </ol>
    </section>
	
	
	
	<?php
	$g = $_GET['id'];
                $result = $db->prepare("SELECT * FROM customer WHERE customer_id='$g' ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		
		$name=$row['customer_name'];
		$o_id=$row['order_id'];
		
		}
	?>
	
	
	
	
	
	
	

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="../../dist/img/user4-128x128.jpg" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $name;?></h3>

              <?php
			  
			  
			  $result = $db->prepare("SELECT SUM(interest) FROM sales WHERE do='' AND order_id='$o_id' ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
			$interest=$row['SUM(interest)'];
			  
		}
			  
			  
			  
	
                $result = $db->prepare("SELECT * FROM credit_sales_order WHERE order_id='$o_id' ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
			$amount=$row['amount'];
		$amount_left=$row['amount_left'];
			$st=$row['status'];
			
			
			$pay=$amount-$amount_left;
			
			
$h1=$amount;
$h2=$amount_left;
$h3=$h1/100;
$h41=$h2/$h3;
$h4=100-$h41;
		
		
		
		}
	?>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Loan Amount</b> <a class="pull-right">Rs.<?php echo $amount;?></a>
                </li>
				<li class="list-group-item">
                  <b>Total Pay</b> <a class="pull-right">Rs.<?php echo $pay;?>.00</a>
                </li>
				<li class="list-group-item">
                  <b>Interest Pay</b> <a class="pull-right">Rs.<?php echo $interest;?>.00</a>
                </li>
                <li class="list-group-item">
                  <b>Loan Balance</b> <a class="pull-right">Rs.<?php echo $amount_left;?></a>
                </li>
				
                <li class="list-group-item">
                  <b>#</b><?php 
				   if($st=="complete"){
				   ?>
				   <span class="badge bg-green"><?php echo$h4;?>%</span><div class="progress progress-sm active">
                      <div class="progress-bar progress-bar-success progress-bar-striped" style="width: <?php echo$h4;?>%"></div>
                    </div></td>
					<?php
                  }
				  
				  else{
					 
				  ?>
				  <span class="badge bg-red"><?php echo$h4;?>%</span><div class="progress progress-sm active">
                      <div class="progress-bar progress-bar-danger progress-bar-striped" style="width: <?php echo$h4;?>%"></div>
                    </div></td>
				  <?php
				  }
				  ?>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box about me -->
 <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php
	$g = $_GET['id'];
                $result = $db->prepare("SELECT * FROM customer WHERE customer_id='$g' ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		
		$name=$row['customer_name'];
		$o_id=$row['order_id'];
		
		
	?>
				
				
				
				<ul class="list-group list-group-unbordered">
				 <li class="list-group-item">
                  <b>Name:</b> <i><?php echo $row['customer_name'];?></i>
                </li>
                <li class="list-group-item">
                  <b>Address:</b>  <i><?php echo $row['address'];?></i>
                </li>
				
				                <li class="list-group-item">
                  <b>Order_id:</b>  <i><?php echo $row['order_id'];?></i>
                </li>
				
				
				<li class="list-group-item">
                  <b>Contact:</b>  <i><?php echo $row['contact'];?></i>
                </li>
				
				<li class="list-group-item">
                  <b>Email:</b>  <i><?php echo $row['email'];?></i>
                </li>
				
				<li class="list-group-item">
                  <b>NIC No:</b>  <i><?php echo $row['nic'];?></i>
                </li>
				
				<li class="list-group-item">
                  <b>Chq No:</b>  <i><?php echo $row['chq_no'];?></i>
                </li>
				
				<li class="list-group-item">
                  <b>Bank:</b>  <i><?php echo $row['bank'];?></i>
                </li>
				
				<li class="list-group-item">
                  <b>Guarantor1:</b>  <i><?php echo $row['guarantor1'];?></i>
                </li>
				
				
				<li class="list-group-item">
                  <b>Guarantor2:</b>  <i><?php echo $row['guarantor2'];?></i>
                </li>
				
				
				<?php } ?>
				
				</ul>
            </div>
            <!-- /.box-body -->
          </div>
       </div>
        <!-- /.col (left) -->
       

         <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">About</a></li>
              <li><a href="#timeline" data-toggle="tab">Timeline</a></li>
              <li><a href="#settings" data-toggle="tab">Settings</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
               
			   
			   
			   <?php
	
                $result = $db->prepare("SELECT * FROM credit_sales_order WHERE cus_name='$name' ORDER by sn DESC ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
			$amount=$row['amount'];
		$amount_left=$row['amount_left'];
			$st=$row['status'];

		
		
		
		
	?>
			   
			   
			   
			   <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-blue">
                          <?php echo $row['s_date'];?>
                        </span>
                  </li>
                
				<li>
				<?php 
				   if($st=="complete"){
				   ?>
				   <i class="fa fa-check bg-green"></i>
					<?php
                  }
				  
				  else{
					 
				  ?>
				  <i class="fa fa-times bg-yellow"></i>
				  <?php }		?>
                    </i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> <?php echo $row['s_date'];?></span>

                      <h3 class="timeline-header"><a href="#">Order id:</a> <?php echo $row['order_id'];?></h3>

                      <div class="timeline-body">
					  
                        <th><label>Loan Amount:-</label><?php echo $row['amount'];?> __ </th>
				  <th><label>Terms:-</label><?php echo $row['terms'];?> __ </th>
                  <th><label>END Date:-</label><?php echo $row['ls_date'];?> __ </th>
				  <th><label>Interest:-</label><?php echo $row['interest'];?>%</th><br>
                  <th><label>Type:-</label><?php echo $row['type'];?></th>





				  
					  
					  </div>
                      <div class="timeline-footer">
                        <?php 
				   if($st=="complete"){
				   ?>
				   <a class="btn btn-success btn-xs">complete</a>
					<?php
                  }
				  
				  else{
					 
				  ?>
				  <a class="btn btn-warning btn-xs">incomplete</a>
				  <?php }		?>
                      </div>
                    </div>
                  </li>
				
		<?php }		?>
				
				</ul>
				

               
                <!-- /.post -->
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-red">
                          10 Feb. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-envelope bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-user bg-aqua"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">Sarah Young</a> accepted your friend request
                      </h3>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-comments bg-yellow"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

                      <h3 class="timeline-header"><a href="#">Jay White</a> commented on your post</h3>

                      <div class="timeline-body">
                        Take me to your leader!
                        Switzerland is small and neutral!
                        We are more like Germany, ambitious and misunderstood!
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-warning btn-flat btn-xs">View comment</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-green">
                          3 Jan. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-camera bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

                      <h3 class="timeline-header"><a href="#">Mina Lee</a> uploaded new photos</h3>

                      <div class="timeline-body">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Experience</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Skills</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
            <!-- /.box-body -->
            
            
          <!-- /.box -->
        
        <!-- /.col (right) -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  
  <!-- /.content-wrapper -->
    <?php
  include("dounbr.php");
?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="../../plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="../../plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="../../plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("YYYY/MM/DD", {"placeholder": "YYYY/MM/DD"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("YYYY/MM/DD", {"placeholder": "YYYY/MM/DD"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'YYYY/MM/DD h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
	$('#datepicker').datepicker({  autoclose: true, datepicker: true,  format: 'yyyy/mm/dd '});
    $('#datepicker').datepicker({
      autoclose: true
    });

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker
    $(".timepicker").timepicker({
      showInputs: false
    });
  });
</script>
</body>
</html>
