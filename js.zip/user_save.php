<?php
session_start();
include('connect.php');

$a = $_POST['cus_name'];
$b = $_POST['date'];



$sql = "UPDATE user 
        SET share=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($b,$a));



		
 date_default_timezone_set("Asia/Colombo");

                  $date =  date("Y/m/d");					
			
				
				date_default_timezone_set("Asia/Colombo");
				$date=date("Y/m/d");
				$date1=date("Y/m/01");
				$date2=date("Y/m/31");
			


header("location: user_rp.php?d1= $date1&d2= $date2");

?>