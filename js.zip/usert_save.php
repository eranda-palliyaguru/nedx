<?php
session_start();
include('connect.php');

$a = $_POST['cus_name'];
$b = $_POST['date'];



$sql = "UPDATE credit_sales_order 
        SET day=?
		WHERE sn=?";
$q = $db->prepare($sql);
$q->execute(array($b,$a));



		
 date_default_timezone_set("Asia/Colombo");

                  $date =  date("Y/m/d");					
			
				
				date_default_timezone_set("Asia/Colombo");
				$date=date("Y/m/d");
				$date1=date("Y/m/01");
				$date2=date("Y/m/31");
			


header("location: usert.php");

?>