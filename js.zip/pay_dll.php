<?php
session_start();
include('connect.php');
date_default_timezone_set("Asia/Colombo");
  
  
 
$id=$_GET['id'];

$result = $db->prepare("SELECT * FROM sales WHERE    transaction_id=:userid  ORDER by transaction_id DESC");
				
					$result->bindParam(':userid', $id);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
$d = $row['order_id'];
$ek=$row['dela'];
$f=$row['interest'];
$amount1=$row['amount'];
$amount=$amount1-$f;
				}


 // .....dela fix.........
$sql = "UPDATE credit_sales_order 
        SET dela=dela-? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($ek,$d));
//...........fix it.............................



//.........amount_left fix..........
$sql = "UPDATE credit_sales_order 
        SET amount_left=amount_left+? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($amount,$d));
//..........fix it.................



$result = $db->prepare("SELECT * FROM sales WHERE    order_id=:userid  ORDER by transaction_id DESC LIMIT    1,1 ");
				
					$result->bindParam(':userid', $d);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
$d = $row['order_id'];
$c=$row['date'];

				}



//.......ls_date fix............
$sql = "UPDATE credit_sales_order 
        SET ls_date=? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($c,$d));
//......fix it.....................


//.......interest_amount fix...............
$sql = "UPDATE credit_sales_order 
        SET interest_amount=interest_amount+? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($f,$d));
//...........fix it.............




$cup="delete";

$sql = "UPDATE sales 
        SET do =? 
		WHERE transaction_id=?";
$q = $db->prepare($sql);
$q->execute(array($cup,$id));

















?>