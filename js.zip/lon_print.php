<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body onload="window.print() " style=" font-size: 13px; font-family: arial;">
<?php

$sec = "1";
?><meta http-equiv="refresh" content="<?php echo $sec;$d1=$_GET['d1'];$d2=$_GET['d2'];?>;URL='pay_rp.php?d1=<?php echo $d1;?>&d2=<?php echo $d2;?>'">	
<div class="wrapper">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
          <i class="fa fa-globe"></i> COLOR BIZ.
		  
          <small class="pull-right">Date:<?php date_default_timezone_set("Asia/Colombo"); 
	                                                        echo date("Y-m-d____h:ia")  ?></small>
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-4 invoice-col">
        TOTAL
        <address>
          <strong></strong><br>
          <?php


		  
		  include("connect.php");
				
				
				
				$d1=$_GET['d1'];
				$d2=$_GET['d2'];
		  
$result = $db->prepare("SELECT sum(amount) FROM credit_sales_order WHERE    s_date BETWEEN '$d1' AND '$d2'  ORDER by sn DESC");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
				  
				  $amount=$row['sum(amount)'];
				}			
			
			echo ' <label>total amount:  </label>';
			echo  $amount;
			echo'<br>';
			echo'<br>';
			echo'<br>';
			echo$d1;
			echo' <label>TO  </label>';
			echo $d2;
			
			?><br>
          <br>
         
        </address>
      </div>
      <!-- /.col -->
      
      
      <!-- /.col -->
    </div>
    <!-- /.row -->
<div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				<th>ORDER ID</th>
				<th>Date</th>
                  <th>Name</th>
                  <th>Amount</th>
                  <th>Terms</th>
                  <th>Interest</th>
				   <th>Fix Interest</th>
				   <th>#</th>
                  
                </tr>
                </thead>
                <tbody>
				<?php
   
  
			
				include("connect.php");
				
				
				
				$d1=$_GET['d1'];
				$d2=$_GET['d2'];
				//$d3=$_SESSION['SESS_FIRST_NAME'];
				//$d3=$_GET['d3'];
				$result = $db->prepare("SELECT * FROM credit_sales_order WHERE    s_date BETWEEN '$d1' AND '$d2'  ORDER by sn DESC");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
				
				
				
			?>
                <tr>
				<td>OR_<?php echo $row['order_id'];?></td>
				<td><?php echo $row['s_date'];?></td>
                  <td><?php echo $row['cus_name'];?></td>
                  <td>Rs.<?php echo $row['amount'];?>
                  </td>
                  <td><?php echo $row['terms'];?></td>
                  <td><?php echo $row['interest'];?>%</td>
				   <td><?php echo $row['interest_amount'];?></td>
                  <td><i class="fa fa-circle-o text-aqua "></i><?php 
				  // $dr=$row['status'];
				  // if($dr=="incomplete"){
					  
					// echo  '<small class="label pull-right bg-yellow">incomplete</small>' ;
					  
					  

				  // }
				  
				  // else{
					  // echo  '<small class="label pull-right bg-green">complete</small>';
				  // }
				}
				   ?></td>
                </tr>
               
                
                </tbody>
				
                <tfoot>
                
				
				
				
				 
				
				
                </tfoot>
              </table>
            </div>
    <!-- Table row -->
   
    <!-- /.row -->

   
        </div>
      
      <!-- /.col -->
    
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>
