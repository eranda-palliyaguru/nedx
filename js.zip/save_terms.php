
<?php
session_start();
include('connect.php');
date_default_timezone_set("Asia/Colombo");
$a = "93903";

$b = $_SESSION['SESS_FIRST_NAME'];
$c = date("Y/m/d");

$d = $_POST['order_id'];

//$result = $db->prepare("SELECT * FROM customer WHERE order_id= :userid");
//$result->bindParam(':userid', $d);
//$result->execute();
//for($i=0; $row = $result->fetch(); $i++){
//$hh=$row['customer_name'];

//}






$interest_amount =$_POST['interest_amount'];


$h=$_POST['cus_name'];

$dela=$_POST['dela'];

$hhid=$_POST['id'];
$e = $_POST['amount'];

$fox = $_POST['interest'];
$f = $_POST['interest'];
$ee=$e-$f;
if($dela<0){
	
$f=$fox+$dela;
	
}


if($e<$f ){
	?>
	
	
<html>
<?php 
include("head.php");
include("connect.php");
?>
<body class="hold-transition skin-blue sidebar-mini">

	
	<br><br><br><br>
	<a href="terms2.php?id=<?php echo $hhid;?>" class="btn btn-default btn-flat">Bak</a>
	
	<br><br><br><br><br>
	<center>
<h1><small class="label  bg-red">Error</small></h1>	
<h3><small class="label  bg-red">Amount is insufficient</small></h3>
	</center>
	
	
<?php	
}
else{


$f = $_POST['interest'];
$ee=$e-$f;



$g = $_POST['due_date'];

$day_pay=$_POST['day_pay'];
$terms_left= $ee/$day_pay;

$sql = "UPDATE credit_sales_order 
        SET terms_left=terms_left-? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($terms_left,$d));




$sql = "UPDATE credit_sales_order 
        SET ls_date=? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($c,$d));

$sql = "UPDATE credit_sales_order 
        SET interest_amount=interest_amount-? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($f,$d));








$user=$_SESSION['SESS_FIRST_NAME'];

$result = $db->prepare("SELECT * FROM user WHERE name='$user' ");
				
					$result->bindParam(':userid', $date);
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
					
					$sha=$row['share'];
					$n=$f/100*$sha;


				}


//edit qty







$amount_left=$_POST['amount_left'];


if($interest_amount<=0){
	
	$cgr=0;
}
else{
	$cgr=$interest_amount;
}
$amount_up=$ee+$cgr;
$amount_don=$ee-$cgr;
$folt=$amount_left-$amount_up;




$full_amount=$_POST['full_amount'];

$ek=$full_amount-$e;


$sql = "UPDATE credit_sales_order 
        SET dela=? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($ek,$d));

$sql = "UPDATE credit_sales_order 
        SET amount_left=amount_left-? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($ee,$d));


if($folt<=0){
	
	
	
	
	$cr="complete";
$sql = "UPDATE credit_sales_order 
        SET status=? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($cr,$d));


$sql = "UPDATE customer 
        SET status=? 
		WHERE order_id=?";
$q = $db->prepare($sql);
$q->execute(array($cr,$d));
	
	
	
}







// query
$sql = "INSERT INTO sales (invoice_number,cashier,date,order_id,amount,interest,due_date,name,user_balance,dela) VALUES (:a,:b,:c,:d,:e,:f,:g,:h,:n,:dela)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':e'=>$e,':f'=>$f,':g'=>$g,':h'=>$h,':n'=>$n,':dela'=>$ek));
header("location: terms.php");

}
?>

    
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="../../plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/input-mask/jquery.inputmask.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="../../plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="../../plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

</body>
</html>
